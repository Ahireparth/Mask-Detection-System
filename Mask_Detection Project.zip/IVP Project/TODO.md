# Real-Time Face Mask Detection Project TODO

## Steps to Complete
- [x] Create requirements.txt with necessary dependencies (opencv-python, numpy)
- [x] Create utils.py with helper functions (e.g., color conversions, distance measures)
- [x] Create image_processing.py with functions for image enhancement (histogram equalization), edge detection (Sobel), morphological operations (dilation, erosion, closing), segmentation (Otsu thresholding), and transforms (DCT for compression if needed)
- [x] Create main.py with the main script for video capture, face detection using Haar cascade, and mask classification logic
- [x] Test the application by running main.py and verifying real-time detection
- [x] Upgrade face detection to OpenCV's DNN-based detector for better handling of masks and movement
- [x] Improve mask detection logic: adjust thresholds, add uniform color checks for mask indication
- [x] Add code to download DNN model files if not present
- [x] Test the updated system for masked and moving faces
