import numpy as np
import cv2

def euclidean_distance(p1, p2):
    """
    Calculate Euclidean distance between two points.
    """
    return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

def city_block_distance(p1, p2):
    """
    Calculate City Block (Manhattan) distance between two points.
    """
    return abs(p1[0] - p2[0]) + abs(p1[1] - p2[1])

def rgb_to_hsv(image):
    """
    Convert RGB image to HSV color space.
    """
    return cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

def hsv_to_rgb(image):
    """
    Convert HSV image to RGB color space.
    """
    return cv2.cvtColor(image, cv2.COLOR_HSV2BGR)

def rgb_to_gray(image):
    """
    Convert RGB image to grayscale.
    """
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def load_image(path):
    """
    Load an image from file path.
    """
    return cv2.imread(path)

def save_image(image, path):
    """
    Save an image to file path.
    """
    cv2.imwrite(path, image)
