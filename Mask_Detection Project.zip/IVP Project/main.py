import cv2
import numpy as np
import urllib.request
import os
from image_processing import histogram_equalization, sobel_edge_detection, closing, otsu_thresholding, color_histogram_equalization, erosion
from utils import rgb_to_hsv

# DNN face detection model paths
MODEL_DIR = 'models'
FACE_PROTO = os.path.join(MODEL_DIR, 'deploy.prototxt')
FACE_MODEL = os.path.join(MODEL_DIR, 'res10_300x300_ssd_iter_140000.caffemodel')

def download_model(url, path):
    """Download model file if not exists."""
    if not os.path.exists(path):
        print(f"Downloading {path}...")
        urllib.request.urlretrieve(url, path)
        print(f"Downloaded {path}")

# Ensure model directory exists
os.makedirs(MODEL_DIR, exist_ok=True)

# Download models if not present
download_model('https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt', FACE_PROTO)
download_model('https://raw.githubusercontent.com/opencv/opencv_3rdparty/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel', FACE_MODEL)

# Load DNN face detector
net = cv2.dnn.readNetFromCaffe(FACE_PROTO, FACE_MODEL)

def detect_mask(face_roi):
    """
    Detect if a mask is present on the face.
    Logic: Check for skin color in mouth area. If low skin pixels and uniform/low saturation, likely masked.
    Balanced thresholds for accuracy.
    """
    # Apply color histogram equalization to normalize lighting
    face_roi = color_histogram_equalization(face_roi)

    # Convert to HSV
    hsv = rgb_to_hsv(face_roi)

    height, width = hsv.shape[:2]

    # Analyze lower part of face (mouth/nose area) - start at 35% and wider for tilted faces
    mouth_hsv = hsv[int(height * 0.35):, int(width * 0.1):int(width * 0.9)]

    # Skin color detection in HSV (narrowed ranges for skin)
    skin_mask = (
        (mouth_hsv[:, :, 0] >= 0) & (mouth_hsv[:, :, 0] <= 30) &
        (mouth_hsv[:, :, 1] >= 30) & (mouth_hsv[:, :, 1] <= 150) &
        (mouth_hsv[:, :, 2] >= 50) & (mouth_hsv[:, :, 2] <= 255)
    )

    # Apply morphological erosion to remove noise
    skin_mask = erosion(skin_mask.astype(np.uint8), kernel_size=3)

    skin_pixels = np.sum(skin_mask)
    total_pixels = mouth_hsv.size // 3
    skin_ratio = skin_pixels / total_pixels if total_pixels > 0 else 0

    # Check for uniform color in mouth area (indicating mask)
    hue_std = np.std(mouth_hsv[:, :, 0])
    sat_std = np.std(mouth_hsv[:, :, 1])
    uniform_color = hue_std < 15 and sat_std < 25

    # Check for low saturation (masks often have low saturation)
    avg_sat = np.mean(mouth_hsv[:, :, 1])
    low_sat = avg_sat < 60

    # If skin ratio is low OR uniform color OR low saturation, likely masked (relaxed conditions for movement)
    if skin_ratio < 0.15 or uniform_color or low_sat:
        return True
    else:
        return False

def main():
    # Open webcam
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Prepare frame for DNN face detection
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300), (104.0, 177.0, 123.0))
        net.setInput(blob)
        detections = net.forward()

        # Detect faces
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            if confidence > 0.3:  # Further lowered confidence threshold for movement
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (x, y, x2, y2) = box.astype("int")
                w_face = x2 - x
                h_face = y2 - y
                # Filter out small detections (likely false positives like eyes)
                if w_face < 50 or h_face < 50:
                    continue
                # Add buffer to face bounding box for better mask capture during movement
                buffer = 15
                x = max(0, x - buffer)
                y = max(0, y - buffer)
                x2 = min(w, x2 + buffer)
                y2 = min(h, y2 + buffer)

                # Draw rectangle around face
                cv2.rectangle(frame, (x, y), (x2, y2), (255, 0, 0), 2)

                # Crop face region
                face_roi = frame[y:y2, x:x2]

                # Detect mask
                mask_present = detect_mask(face_roi)

                # Label the face
                label = "Mask" if mask_present else "No Mask"
                color = (0, 255, 0) if mask_present else (0, 0, 255)
                cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

        # Display the frame
        cv2.imshow('Real-Time Face Mask Detection', frame)

        # Exit on 'q' key
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()