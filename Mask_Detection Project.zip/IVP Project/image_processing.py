import numpy as np
import cv2
from utils import rgb_to_hsv, hsv_to_rgb, rgb_to_gray

def histogram_equalization(image):
    """
    Perform histogram equalization on a grayscale image.
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    return cv2.equalizeHist(image)

def log_transformation(image, c=1.0):
    """
    Apply log transformation to enhance image.
    """
    image = image.astype(np.float32)
    transformed = c * np.log(1 + image)
    return np.uint8(cv2.normalize(transformed, None, 0, 255, cv2.NORM_MINMAX))

def power_law_transformation(image, gamma=1.0, c=1.0):
    """
    Apply power law (gamma) transformation.
    """
    image = image.astype(np.float32)
    transformed = c * (image ** gamma)
    return np.uint8(cv2.normalize(transformed, None, 0, 255, cv2.NORM_MINMAX))

def contrast_stretching(image, r1=0, s1=0, r2=255, s2=255):
    """
    Apply piecewise linear contrast stretching.
    """
    image = image.astype(np.float32)
    transformed = np.where(image <= r1, (s1 / r1) * image if r1 != 0 else 0,
                           np.where(image <= r2, ((s2 - s1) / (r2 - r1)) * (image - r1) + s1,
                                    ((255 - s2) / (255 - r2)) * (image - r2) + s2))
    return np.uint8(transformed)

def thresholding(image, threshold=127):
    """
    Apply simple thresholding.
    """
    _, thresh = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY)
    return thresh

def sobel_edge_detection(image):
    """
    Apply Sobel edge detection.
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    sobelx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    sobel = np.sqrt(sobelx**2 + sobely**2)
    return np.uint8(cv2.normalize(sobel, None, 0, 255, cv2.NORM_MINMAX))

def prewitt_edge_detection(image):
    """
    Apply Prewitt edge detection.
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    kernelx = np.array([[1, 0, -1], [1, 0, -1], [1, 0, -1]])
    kernely = np.array([[1, 1, 1], [0, 0, 0], [-1, -1, -1]])
    prewittx = cv2.filter2D(image, -1, kernelx)
    prewitty = cv2.filter2D(image, -1, kernely)
    prewitt = np.sqrt(prewittx**2 + prewitty**2)
    return np.uint8(cv2.normalize(prewitt, None, 0, 255, cv2.NORM_MINMAX))

def median_filter(image, ksize=3):
    """
    Apply median filter for noise reduction.
    """
    return cv2.medianBlur(image, ksize)

def gaussian_blur(image, ksize=(3,3), sigma=0):
    """
    Apply Gaussian blur.
    """
    return cv2.GaussianBlur(image, ksize, sigma)

def dilation(image, kernel_size=3):
    """
    Apply morphological dilation.
    """
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    return cv2.dilate(image, kernel, iterations=1)

def erosion(image, kernel_size=3):
    """
    Apply morphological erosion.
    """
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    return cv2.erode(image, kernel, iterations=1)

def opening(image, kernel_size=3):
    """
    Apply morphological opening (erosion followed by dilation).
    """
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    return cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)

def closing(image, kernel_size=3):
    """
    Apply morphological closing (dilation followed by erosion).
    """
    kernel = np.ones((kernel_size, kernel_size), np.uint8)
    return cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)

def otsu_thresholding(image):
    """
    Apply Otsu's thresholding for automatic threshold selection.
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    _, thresh = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

def dct_compression(image, quality=50):
    """
    Apply DCT for image compression (simplified).
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    dct = cv2.dct(np.float32(image))
    # Simple compression by zeroing out high frequencies
    rows, cols = dct.shape
    mask = np.zeros((rows, cols), np.uint8)
    mask[:int(rows * quality / 100), :int(cols * quality / 100)] = 1
    dct_compressed = dct * mask
    reconstructed = cv2.idct(dct_compressed)
    return np.uint8(cv2.normalize(reconstructed, None, 0, 255, cv2.NORM_MINMAX))

def region_growing(image, seed, threshold=10):
    """
    Simple region growing segmentation.
    """
    if len(image.shape) == 3:
        image = rgb_to_gray(image)
    height, width = image.shape
    segmented = np.zeros_like(image)
    visited = np.zeros_like(image, dtype=bool)
    stack = [seed]
    seed_value = image[seed]
    while stack:
        x, y = stack.pop()
        if visited[x, y]:
            continue
        visited[x, y] = True
        if abs(int(image[x, y]) - int(seed_value)) <= threshold:
            segmented[x, y] = 255
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < height and 0 <= ny < width and not visited[nx, ny]:
                    stack.append((nx, ny))
    return segmented

def color_histogram_equalization(image):
    """
    Perform histogram equalization on color image (in HSV space).
    """
    hsv = rgb_to_hsv(image)
    hsv[:, :, 2] = histogram_equalization(hsv[:, :, 2])
    return hsv_to_rgb(hsv)
